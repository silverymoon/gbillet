#!/bin/bash
java -Djava.ext.dirs=lib -cp billet.jar billet.BilletApp
